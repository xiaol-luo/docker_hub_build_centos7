+++
date = "2015-03-17T15:36:56Z"
title = "Getting help"
[menu.main]
  weight = 90
  pre = "<i class='fa fa-question'></i>"
+++

Often, the quickest way to get support for general questions is through
the
[MongoDB Community Forums](https://community.mongodb.com/tags/c/drivers-odms-connectors/7/cxx-driver)
or through
[Stack Overflow](https://stackoverflow.com/questions/tagged/mongodb%20c%2b%2b).

Please also refer to MongoDB's
[support channels](https://docs.mongodb.com/manual/support) documentation.

